<?php

use Illuminate\Support\Facades\Route;
Use App\Http\Controllers\UserController;
Use App\Http\Controllers\DashboardController;
Use App\Http\Controllers\StudentController;
Use App\Http\Controllers\MailController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('login',[UserController::class, 'login'])->name('login');
Route::get('form',[UserController::class, 'form'])->name('form');
Route::post('formpost',[UserController::class, 'formpost'])->name('formpost');
Route::post('loginpost',[UserController::class, 'loginpost'])->name('loginpost');
Route::get('logout',[UserController::class, 'logout'])->name('logout');
Route::resource('student',StudentController::class);


Route::group(['middleware' => 'auth'], function(){
    Route::get('dashboard',[DashboardController::class, 'dashboard'])->name('dashboard');

});

Route::get('sendemail',[MailController::class, 'email'])->name('email');
Route::get('otp/{id}',[MailController::class, 'otp'])->name('otp');