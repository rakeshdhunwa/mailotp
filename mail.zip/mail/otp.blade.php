<form action="{{route('otp',$data->id)}}">

    <input type="text" name ="otp">
    <input type="submit" name="submit" value="submit">

</form>