<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Mail\Login;
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
    public function login(){
       return view('login');
    }

    public function form(){
        return view('register');
     }

     public function formpost(Request $request){
        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'password' => 'required|min:6|same:cpassword',
        ]);
        $alldata = $request->all();

        $user = [
            'name'=> $alldata['name'],
            'email'=> $alldata['email'],
            'password'=> Hash::make($alldata['password']),
        ];

        $data = User::create($user);
        return redirect()->route('login');
     }

     public function loginpost(Request $request){
        $request->validate([
            'email'=>'required',
            'password'=>'required',
        ]);
        $logindata = $request->only('email','password');

        // print_r($logindata);

      if(Auth::attempt($logindata)){
       

        $data = [
            'otp' => rand(1000, 9999)
        ];

        Mail::to($logindata['email'])->send(new Login($data));
        
         return redirect()->route('dashboard')->withSuccess('login SuccessFully...');
      }else{
        return redirect()->route('login')->withSuccess('inbeld cressan');
      }
     }
     public function logout(){
        Auth::logout();
        return redirect()->route('login')->withSuccess('Logout SuccessFully...');
     }
}
