<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Mail;
use Illuminate\Auth\Events\Verified;
use App\Mail\Login;
use Illuminate\Foundation\Auth\EmailVerificationRequest;

class MailController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
     public function email()
    {   
        
        // $user = User::first();
    $data =   User::where('email','sumit10020404@gmail.com')->first();
    if($data){

        $data = User::find($data->id);
        $data->otp = rand(1000,9999);
        $data->save();
        // User::where('id',$data);
        Mail::to('sumit10020404@gmail.com')->send(new Login($data));

    }else{
    }
        // $user = [
        //     'name' => 'sumit',
        //     'email' => 'sumit@10020404@gmail.com',
        //     'password' => md5('test1234'),
        //     'otp' => rand(1000,9999),
        // ];

        // User::create($user);

        // $user->sendEmailVerificationNotification();
        return view('otp',compact('data'));
    }
    public function otp(Request $request, $id){
        // echo  $id;
        // print_r($request->all());die;

        $data = User::find($id);

        if($data->otp == $request['otp']){
            return view('otp');
        }else{
            die('unsuccsu');

        }

    }
}
